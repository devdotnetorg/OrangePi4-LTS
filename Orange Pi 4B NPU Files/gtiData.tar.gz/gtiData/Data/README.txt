Images folders:
  Image_bmp_20:    images to test gNet1 and gNet3 20 classes models.
  Image_bmp_c40:   images to test gNet1, gNet3, MobileNet and ResNet 40 
                   classes models.
  Image_bmp_c1000: images to test gNet1 and gNet3 1000 classes models.
  Image_lite:      raw BGR and RGB planar format image to test gNet1, 
                   gNet3, MobileNet and ResNet 20/40/1000 classes models.
  Image_dog:       images to test gNet18 40 dogbreed classes model

Video files are under directory 
Image_mp4:
  All_40class.mp4:   video to test gNet1, gNet3, MobileNet and ResNet 40
                     classes models.
  video_40class.avi: video to test gNet1, gNet3, MobileNet and ResNet 40 
                     classes models.
  video_20class.mp4: video to test gNet1 and gNet3 20 classes models.
